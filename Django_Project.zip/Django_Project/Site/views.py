from django.shortcuts import render

def coming_soon_view(request, url):
    return render(request, 'coming/index.html')