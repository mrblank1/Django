from django.shortcuts import render

def coming_soon_view(request):
    return render(request, 'coming/index.html')