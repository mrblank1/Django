from django.contrib import admin

# Register your models here.
from mywebsite.models import Contact,NewsLetter

@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    # Optional: Customize the list of displayed fields
    list_display = ['name', 'email']

@admin.register(NewsLetter)
class newsletterAdmin(admin.ModelAdmin):
    list_display=['email', ]

