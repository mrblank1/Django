from django import template
from blog.models import Post
register = template.Library()

@register.inclusion_tag('website/latest_blog.html')
def latest_blog():
    posts=Post.objects.filter(status=True).order_by('published_date')[:6]
    return {'posts': posts}
