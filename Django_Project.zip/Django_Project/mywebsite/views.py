from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect
from blog.forms import NameForm,ContactForm,NewsLetterForm
from django.contrib import messages
def http_test(request):
    return HttpResponse("<h1>hello</h1>")
def home(request):
    return render(request,'website/index.html')
def contact_us(request):
    if request.method == 'POST':
        form=ContactForm(request.POST)
        form.fields['subject'].required = False
        if form.is_valid():
            contact_instance = form.save(commit=False)
            contact_instance.name = 'Unknown'
            contact_instance.save()
            form.save() 
            messages.add_message(request, messages.SUCCESS , "your submitted successfully")
        else:
            messages.add_message(request, messages.ERROR , "your ticket did not validate")
    
    form=ContactForm()
    return render(request,'website/contact.html',{'form':form})
def about(request):
    return render(request,'website/about.html')
def elements(request):
    return render(request,'website/elements.html')
def newsletter(request):
    if request.method == 'POST':
        form=NewsLetterForm(request.POST)
        if form.is_valid():
            form.save()
            print('done')
            return HttpResponseRedirect('/')
        else:
            print('error')
            return HttpResponseRedirect('/')
        
    form=NewsLetterForm()

# Create your views here.
