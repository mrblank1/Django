from django.shortcuts import render,get_object_or_404,HttpResponse
from blog.models import Post
from django.utils import  timezone
from mywebsite.models import Contact
from blog.forms import NameForm,ContactForm
from django.contrib.auth.decorators import login_required
# from PIL import Image
@login_required
def blog_view(request,**kwargs):
    now = timezone.now()
    posts=Post.objects.filter(published_date__lte=now,status=1)
    if kwargs.get('tag_name') != None :
        posts=posts.filter(tags__name__in=[kwargs['tag_name']])
        # posts=posts.filter(tag_name
    context={'posts':posts}
    return render(request, 'blog/blog-home.html',context)
# I want to show the views in the blog-single
def blog_single(request,pid=1):
    posts=Post.objects.filter(published_date__lte=timezone.now(),status=1)    
    post=get_object_or_404(posts,pk=pid)
    previous_post = posts.filter(pk__lt=post.pk).order_by('-pk').first()
    next_post = posts.filter(pk__gt=post.pk).order_by('pk').first()
    prev_next = {
        'previous': previous_post,
        'next': next_post,
    }
    post.counted_views+=1
    post.save()
    context={'post':post,
             'prev_next':prev_next}
    return  render(request, 'blog/blog-single.html',context)
# Create your views here.
# in the test I tried to call it
def blog_test(request):
    c=Contact()
    # if request.method == 'POST':
    #     form=ContactForm(request.POST)
    #     if form.is_valid():
    #         form.save()
    #         return HttpResponse("done")
    #     else:
    #         return HttpResponse(" not valid")
        
    # form=ContactForm()
    context={'form':'sdf'}
    return render(request, 'blog/test.html',context)
def blog_category(request,cat_name):
    posts=Post.objects.filter(status=1)
    posts=posts.filter(category__name=cat_name)
    context={'posts':posts}
    return render(request,'blog/blog-home.html',context)
