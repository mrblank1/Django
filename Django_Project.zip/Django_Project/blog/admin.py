from django.contrib import admin
from blog.models import Post,Category
from django_summernote.admin import SummernoteModelAdmin
# Register your models here.
@admin.register(Post)
class PostAdmin(SummernoteModelAdmin):
    date_hierarchy = 'created_date'
    empty_value_display = '-empty-'
    list_display=('title','id','author', 'status','published_date')
    list_filter=('status','author' )
admin.site.register(Category)

# from .models import SomeModel

