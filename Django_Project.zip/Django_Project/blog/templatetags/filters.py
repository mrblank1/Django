from django import template
from django.utils.html import strip_tags

register = template.Library()

@register.filter
def excerpt_words(value, word_count):
    # Remove HTML tags from the content
    text = strip_tags(value)
    
    # Split the text into words
    words = text.split()
    
    # Check if the content has more words than the desired word count
    if len(words) > word_count:
        excerpt_words = ' '.join(words[:word_count]) + '...'
    else:
        excerpt_words = ' '.join(words)
    
    return excerpt_words
