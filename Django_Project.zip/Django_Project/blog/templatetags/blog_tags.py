from django import template
from blog.models import Post
register=template.Library()

@register.simple_tag(name='simple')
def hello():
    posts=Post.objects.filter(status=True).count()
    return posts

@register.inclusion_tag('blog/popular_posts.html')
def popularposts():
    posts=Post.objects.filter(status=True).order_by('published_date')
    return {'posts': posts}